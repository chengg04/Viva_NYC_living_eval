show databases;
use sakila;
show tables;
select * from nycdata;
CREATE TABLE sevenmajor AS (select* from nycdata where crime='TOTAL SEVEN MAJOR FELONY OFFENSES'); 
select * from sevenmajor;
ALTER TABLE sevenmajor DROP COLUMN CRIME;
select * from sevenmajor;
select* from PCT;
SELECT sum(2011) from nycdata where PCT between 1 and 17 and CRIME='MURDER & NON NEGL. MANSLAUGHTER';                               ;
SELECT AVG(2011) FROM nycdata WHERE PCT between 1 and 17 and CRIME='MURDER & NON NEGL. MANSLAUGHTER'; 
ALTER TABLE nycdata ADD PCT_sum varchar(50);
select * from nycdata;


